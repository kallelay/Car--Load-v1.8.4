#pragma once

#include "stdafx.h"

using namespace irr;
using namespace video;
using namespace System;

namespace IrrlichtLime {
namespace Video {

public enum class PolygonOffset
{
	Back = EPO_BACK,
	Front = EPO_FRONT
};

} // end namespace Video
} // end namespace IrrlichtLime