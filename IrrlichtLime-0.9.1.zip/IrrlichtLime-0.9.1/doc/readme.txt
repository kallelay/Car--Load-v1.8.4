This folder contains documentation related files.

IrrlichtLime.xml
----------------
The file contains Visual Studio IntelliSense data. This file is being copy to bin directory each time IrrlichtLime is compiled. This file related to IrrlichtLime.dll only and necessary only for developing in Visual Studio (you do not need to provide this file for end user of your project). If you delete this file, all will continue work fine, the only IntelliSense will stop helping you with types, methods and their arguments.
